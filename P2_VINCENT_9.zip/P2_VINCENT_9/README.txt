Bienvenue sur notre site d'analyse de la Ferme des 3 Chênes. 

Comme vous pourrez le voir, celui-ci est loin d'être fini et ne porte pas encore toutes les options nécessaires, mais est déjà sur une bonne lancée. 

COMMENT LANCER LE SITE:
-----------------------

Prérequis:
1) Soyez connecté à internet (pour que chart.js fonctionne)
2) Ayez le module flask installé sur votre pc, pour cela il suffit de lancer la commande 
	'pip install flask' 
-> Bien évidemment, pour que pip fonctionne python doit être installé. La version de python doit être au minimum python3

Le lancement:
-> Afin de lancer le site, il faut faire attention à ne pas créer de bug dû à VScode par exemple, pour cela suivez bien l'explication ci-dessous

1) Le plus simple pour éviter tout bug est de lancer le programme depuis le terminal.
--> Sur windows, allez dans le dossier où se trouve 'main.py' ...../flaskr/main.py grâce à l'explorateur de fichier
	-> Une fois dedans, lancez le terminal dans ce dossier (cliquez sur l'adresse du fichier en haut de la page et écrivez cmd) https://www.thewindowsclub.com/wp-content/uploads/2009/04/cmd-in-folder.png?ezimgfmt=ng:webp/ngcb188 
	-> Une fois dans le terminal, lancez la commande suivant:
		'python3 main.py'
	
--> Sur Linux/Mac, ouvrez un terminal et rendez-vous dans le dossier où se trouve main.py, pour cela, utilisez la commande cd:
	cd .../.../P2_VINCENT_9/flaskr/ (les ... représentent vos dossiers, l'emplacement du dossier P2 dépend de là où vous l'avez extrait)
	--> Une fois dedans, lancez la commande suivante:
		'python3 main.py' 

-> Copiez l'adresse donnée et entrez la sur un navigateur (Firefox de préférence mais Chrome fonctionne correctement aussi, (ainsi que Safari sur Mac) (normalement))

LE SITE:
--------

Vous êtes automatiquement redirigé vers la page home, où se trouvent quelques infos sur la ferme. N'hésitez pas à vous balader et à lire si cela vous chante.

-> Pour accéder aux schémas, cliquez sur "analytics" en haut à droite. Une fois dessus, vous aurez l'occasion de sélectionner les paramètres voulus et ensuite d'afficher le graphe en cliquant sur "Afficher le Graphe". 

Ce qui marche:
- - - - - - - -
- "Graphe à afficher": vêlages. Le choix des dates influencent bien le graphe, cependant la famille pas encore. 

- "Graphe à afficer": Pleine Lune. Les dates influencent bien le graphe, cependant la famille pas encore.

Ce qui ne marche pas:
- - - - - - - - - - -
- Le reste, nous avons malheureusement eu quelques soucis dans la répartitions des taches causant des délais dans le rendu final... Le Html fonctionne correctement et le javascript aussi, le Css est aussi bon. Il ne reste plus qu'à récupérer certaines informations et les envoyer et le projet sera pratiquement complet.  
 
- Nous pouvons aussi ajouter quelques infos en plus dans les paragraphes

FONCTIONNEMENT GÉNÉRAL:
-----------------------
|
| ~flaskr
-- |
   | ~static
   -- |
      | - style.css (pour le style)
      | - favicon.ico (icône du site)
      | - vache.jpg (image pour la page home)
   |
   | ~templates
   -- |
      | - base.html (squelette du site pour l'héritage)
      | - home.html (page d'accueil)
      | - analytics.html (page de choix des options de graphe et les "envoie" à flask)
      | - graph.html (page avec le javascript qui récupère les infos de flask)
   |
   | - database.db (data du site contenant toutes les infos)
   | - schema.sql (schema de la base de donnée)
   | - function.py (fonction de la création des paramètres d'affichage de graphes)
   | - main.py (lanceur du site et récupérateur des infos données par les utilisateurs, les envoie ensuite à function.py qui retourne les données ensuite injectées dans graph.html)
 
      
      
